#import os
#print("Current Working Directory:", os.getcwd())
from shapes2 import cylinder_volume, triangle_area


base = float(input("Enter the base of the triangle: "))
height = float(input("Enter the height of the triangle: "))
radius = float(input("Enter the radius of the cylinder: "))
cylinder_height = float(input("Enter the height of the cylinder: "))

triangle_area_result = triangle_area(base, height)
cylinder_volume_result = cylinder_volume(radius, cylinder_height)


print("Area of the triangle:",triangle_area_result)
print("Volume of the cylinder:",cylinder_volume_result )