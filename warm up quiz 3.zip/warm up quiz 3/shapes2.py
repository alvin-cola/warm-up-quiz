import math
def triangle_area(base,height):
    Area=0.5*base*height
    return Area

def cylinder_volume(radius,cylinder_height):
    """calculates the  volume of the cylinder"""
    Volume=math.pi*radius**2*cylinder_height
    return Volume