def calculate_triangle_area(base,height):
 """Calculates the area of a triangle."""
 area=0.5*base*height
 return area
base=2
height=3
triangle_area=calculate_triangle_area(base,height)
print (f"The area of a triangle is {triangle_area}")