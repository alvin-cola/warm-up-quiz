def calculate_circle_area(radius):
 """calculates the area of a circle"""
 pi=3.14
 area=pi*radius*radius
 return  area
radius=2
calculate_area=calculate_circle_area(radius)
print (f"The area of a circle when radius is {radius} is equal to {calculate_area }")