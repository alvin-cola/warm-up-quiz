def miles_per_gallon(miles_driven,gallons_of_gas_used):
    MPG=miles_driven/gallons_of_gas_used
    return MPG
miles_driven=float(input("Enter the miles driven:"))
gallons_of_gas_used=float(input("Enter the gallons of gas used:"))
MPG=miles_per_gallon(miles_driven,gallons_of_gas_used)
print(f"MPG={MPG:.2f}")