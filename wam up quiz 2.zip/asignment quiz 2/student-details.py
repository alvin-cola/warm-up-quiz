Student_Name=input("Sudent Name=")
Student_Number=input("Student Number=")
Programming_Marks=float(input("Programing="))
Data_Science_marks=float(input("Data Science="))
Computer_Applications_marks=float(input("Computer Applications="))
average=(Programming_Marks + Data_Science_marks +Computer_Applications_marks )/3
print("****STUDENT DETAILS****")
print(f"Sudent Name={Student_Name} \nStudent Number={Student_Number} \nPrograming={Programming_Marks}  \nData Science{Data_Science_marks}  \nComputer Applications{Computer_Applications_marks} \nAverage Marks={average:.3f}")