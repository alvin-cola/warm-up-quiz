import math
def volume_of_a_sphere(radius):
    Volume=4/3*math.pi*radius**2
    return Volume
radius=float(input("Enter the radius:"))
Volume=volume_of_a_sphere(radius)
print (f"Volume={Volume:.2f}")

