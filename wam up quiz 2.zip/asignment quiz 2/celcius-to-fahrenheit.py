def celcius_to_fahrenheigt(celcius):
    Fahrenheit=9/5*celcius+32
    return Fahrenheit
celcius=float(input("Enter degrees in Celcius:"))
Fahrenheit=celcius_to_fahrenheigt(celcius)
print (f"{celcius} degrees celcius is equal to {Fahrenheit} degrees fahrenheit")